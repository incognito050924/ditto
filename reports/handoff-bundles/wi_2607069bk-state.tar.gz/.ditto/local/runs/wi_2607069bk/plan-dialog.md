---
kind: plan-dialog
work_item_id: wi_2607069bk
---

# plan-dialog

## 사용자 Q&A
(none)

## QuestionGate self-answer (안 물은 근거)
(none)

## assumptions
(none)

## 닫힌 항목
- [resolved] cov-root: work item이 Record(영속·공유·committed tier)와 Run(일회성·개인·gitignored tier)으로 스키마·물리 분리되어, Record가 git으로 공유되고 Run을 지워도 프로젝트 기억이 보존되며, A1·A2·B1·C1·C5 정합 갭이 닫힌 상태로 전체 테스트가 GREEN이다
- [out_of_scope] cov-cat-authentication: 이 기능에 도달하는 인증 경로·방식은? (API 토큰·웹 세션·서버간 OAuth·서비스 토큰 등) 경로별 인증이 이 변경에서 일관·정확한가? 한 방식만 가정하고 다른 진입 경로를 빠뜨리지 않나? — skip: CLI+core+schema refactor of on-disk work-item state; no endpoint/session exposed, GitHub auth owned by gh CLI (github-progress/claim hold no token), C5 relocates idempotency markers not an auth mechanism. · risk: If a consumer gated a GitHub write on the reduced idempotency set while gh was mis-authenticated, a rejected post could record as posted — github idempotency correctness (cross-feature/external-env), not an auth-path defect this change adds.
- [out_of_scope] cov-cat-authorization: 이 제품의 인가(authorization) 모델은 무엇인가? (역할기반 RBAC·속성기반 ABAC·관계기반 ReBAC·ACL·소유권·테넌트 경계·OAuth 스코프·정책엔진 등 — 제품마다 다르며 RBAC가 기본값이 아니다) 이 변경이 요구·부여하는 권한이 그 모델과 일관·정확한가? 한 모델만 가정하고 다른 인가 경로를 빠뜨리지 않나? 누가 접근 가능/불가해야 하나? — skip: No product authz model (no RBAC/ABAC/tenant/policy); owner_profile is an execution-permission enum (common.ts:37), not an access subject; fs+git govern access and are untouched. · risk: Split newly commits Record to shared repo = visibility shift for previously-personal state; swept under pii-leak/secret-exposure, no per-WI access control exists to regress.
- [resolved] cov-cat-auditing: 이 동작에 감사 로그·추적이 필요한가? 누가·언제·무엇을 했는지 남나? 행위자가 행위를 부인할 수 있나, 기록은 변조내성·귀속가능(tamper-evident)한가?
- [resolved] cov-cat-data-integrity: 데이터 손실·손상·부분쓰기·멱등·마이그레이션 영향이 있나?
- [resolved] cov-cat-boundary-edge: 경계값/극단 입력이 있나? (0·최대·빈값·오버플로·경계 전환)
- [resolved] cov-cat-concurrency-ordering: 레이스·락·중복·이벤트 순서 문제가 있나?
- [resolved] cov-cat-external-env: 외부 환경(env/배포/3rd-party)으로 깨질 우려가 있나? 이 변경의 side-effect는 무엇인가(외부 API 호출·메시지 발행 등)?
- [resolved] cov-cat-failure-recovery: 실패 지점에서 부분 recovery가 필요한가, 전체 롤백인가? 무성 실패·연쇄 실패·fallback 정확성은?
- [resolved] cov-cat-resource-exhaustion: 한도·고갈·타임아웃·메모리·N+1·스케일 문제가 있나? 정상 부하가 늘 때 자원이 고갈되거나 성능이 붕괴되나? (용량 한계 — 의도적 오남용은 #abuse-vector)
- [out_of_scope] cov-cat-abuse-vector: 이 흐름을 한도/쿼터보다 빠르게 악용할 수 있나(대량·replay·스크래핑·credential stuffing)? 레이트리미터가 공유라 우회·고갈시킬 수 있나? (의도적 오남용 벡터 — 정상 부하의 용량 한계는 #resource-exhaustion) — skip: Local single-dev CLI on own repo; no untrusted remote actor/rate-limiter/quota in scope; event actor is a local profile/session; event_id dedupe covers accidental replay not adversarial flooding. · risk: A repo-write party could forge events (arbitrary seq/actor) to steer terminal-first-wins or inject claim markers — but repo-write already grants full file control, so this is data-integrity/concurrency trust, not an external abuse vector.
- [resolved] cov-cat-compat-version: 하위/상위 호환·스키마/API 진화·파괴적 변경이 있나?
- [out_of_scope] cov-cat-injection: 신뢰할 수 없는 입력이 코드·쿼리·명령으로 해석되는 인젝션 경로가 있나? (SQL·NoSQL·OS 명령·LDAP·XPath·템플릿·역직렬화 싱크 — CWE-89/78/94, OWASP A03) 입력이 위험한 인터프리터에 도달하나? (입력 검증 게이트 자체는 #input-validation) — skip: No untrusted-input-to-interpreter sink (no SQL/OS-cmd/template); gh via execFileSync no-shell argv; event payloads JSON+zod validated; inputs local/authoring not an untrusted boundary. · risk: events/<seq>.<actor>.<eid>.json path is safe only because actor=profileName enum today; if actor later widens to a free session id, open(wx) becomes a path-traversal sink — pin/sanitize the actor path segment + test hostile-actor (scope-creep guard, not a T0 blocker).
- [resolved] cov-cat-secret-exposure: 시크릿·자격증명·토큰·키가 코드·로그·에러·설정·URL에 노출되나? 저장·전송 시 적절히 보호되나? (CWE-200/532, OWASP A02)
- [resolved] cov-cat-pii-leak: 개인식별정보(PII)·민감 데이터가 수집·로깅·전송·노출되나? 최소수집·마스킹·암호화·접근통제가 적용되나?
- [out_of_scope] cov-cat-regulatory: 규제·컴플라이언스 의무가 이 변경에 걸리나? (GDPR·개인정보보호법·데이터 보존/삭제·국외이전·동의·감사요건 — 위반 시 법적/계약 위험) — skip: Internal dev-tool's own work-item metadata; no regulated data subject or compliance duty; no new third-party PII collection/transfer introduced. · risk: Split commits authoring identity (GitHub login, github-claim.ts:45) + free-text goal to immutable git history that cannot be hard-deleted; if a project treats contributor identity as regulated PII, git's no-erasure conflicts with a deletion duty — exposure itself swept under pii-leak, legal framing is a project-policy call outside this mechanism.
- [resolved] cov-cat-cross-feature: 기능적으로 먼 feature와 공유 자원/상태를 건드리나? (memory graph entanglement가 주로 채움)
- [resolved] cov-cat-observability: 로깅 공백·알림 부재·디버깅성 문제가 있나? 무성/부분 실패를 어떤 signal이 잡고, 인지까지 얼마나 걸리나?
- [resolved] cov-cat-deployment-rollout: 적용/배포 타이밍·순서가 중요한가? 의존(받는/하는) 타 기능보다 먼저/나중 배포돼야 하나? git·릴리스 정책(브랜치 전략·feature flag·릴리스 트레인·핫픽스)과 맞나? 부분 롤아웃 중 혼재 버전이 깨지나? 마이그레이션-코드 배포 순서는?
- [resolved] cov-cat-reuse-build-vs-buy: 신규 구현 전에 reuse→adopt→build 순으로 따졌나? (내부) 코드베이스에 이미 있는 재사용 가능한 패턴·컴포넌트를 채택했나, 아니면 재발명했나? (외부) 검증된 OSS·SDK가 있나 — 라이선스(copyleft)·비용·CVE·유지보수 활성도·공급망 위험은? 신규 구현이면 reinvent 비용·품질 리스크는? (이 렌즈는 기존 자산 채택 vs 재발명 결정 — 만들기로 한 뒤 이 변경 자체의 추상화 적정선·과잉/과소는 #minimal-increment의 몫)
- [resolved] cov-cat-input-validation: 신뢰할 수 없는 입력의 형태·타입·의미가 사용 전에 검증되나? (malformed payload·type confusion·역직렬화 — CWE-20/502, OWASP A03/A08)
- [resolved] cov-cat-configuration: 코드가 아닌 설정·플래그·기본값·env 값이 실패를 부르나? 새 설정이 라이브 전에 검증되나? (OWASP A05 misconfiguration)
- [resolved] cov-cat-time-clock: 정확성이 시간 자체에 의존하나 — 만료(토큰·TTL·인증서)·타임존/DST·monotonic vs wall clock·노드 간 시계 일치?
- [resolved] cov-cat-minimal-increment: 이게 의도를 달성하는 가장 명료하고 작은 증분인가? 추상화가 지금의 실제 복잡도에 비례하나 — 요청되지 않은 기능·설정가능성·확장성, 미래 대비/단일 사용/얕은 추상화로 과하지 않나(과잉이 흔한 실패)? 거꾸로, 이 변경이 새로 들이는 중복·반복을 마땅히 묶지 않아 모자라지 않나(중복은 버그·드리프트의 원천)? 변경한 모든 줄에 요청과 연결된 이유가 있고, 관련 없는 리팩터·포맷 정리가 섞이지 않았나? (목표는 추상화 회피가 아니라 적정 — 실제 복잡도를 줄일 때만 추상화한다. 기존 재사용 가능 자산을 채택했는지는 #reuse-build-vs-buy의 몫)

## 열린 항목
(none)
