# 핸드오프 — far-field 신뢰성 재설계 autopilot 재개 (wi_260706n4w)

> **성격**: WI 없는 세션 핸드오프. **단일 소비·읽고 나면 archive.** durable은 코드·intent.json·메모리에 있으니 이 파일은 pickup용.
> **작성**: 2026-07-07 · 이 세션이 측정(wi_26062227h)+계측 슬라이스 랜딩+전체 deep-interview로 포화 → 헌장 §4-9로 **plan 설계 경계에서 handoff**. autopilot은 영속돼 재개 가능.

## 한 줄 상태
**wi_260706n4w(far-field 신뢰성 재설계) — 설계·연구 단계 완료. plan 잠금 + 9노드 DAG 승격 + n1-research(2 unknown 해소) DONE. autopilot `orch_2607072xc`.** passed: N1(design)·n1-research. **다음 = n2-schema(첫 mutation 노드) → n3 taxonomy → n4 oracle-core → n5 wiring → n6 deep-interview-seed → n7 review → n8 verify → n9 measure.** 코드 변경 아직 0(다음이 착수). 재개 = `ditto autopilot next-node --workItem wi_260706n4w`로 바로 n2.

## ⚠ 구현 계약 (반드시 먼저 읽어라)
- **`.ditto/local/work-items/wi_260706n4w/oracle-design-decisions.md`** — n1-research가 확정한 oracle 설계 계약(absence claim shape·exit 3분기·grep-only·AcOracle 재사용·라벨러 순환차단). n2/n4/n5/n9는 이걸 재결정 말고 그대로 구현.
- **plan_brief(autopilot.json approval_gate.plan_brief)** — coverage sweep이 찾은 24개 구현 제약(injection argv+-F+--·enforceClose conditional fail-open·count 테스트 23→22·minimal-increment 제거 silent-narrowing 주의 등).
- `.ditto/local/runs/wi_260706n4w/coverage.json`·`plan-dialog.md` — sweep 원장(17 resolved·6 skipped).

## SoT 포인터 (권위 = 코드+intent, 이 파일 아님)
- **의도(권위)**: `.ditto/local/work-items/wi_260706n4w/intent.json` — goal + 7 AC + in_scope/out_of_scope + 2 unknowns. **먼저 읽어라.**
- **9노드 DAG + decision_conflicts(재개 입력)**: `.ditto/local/work-items/wi_260706n4w/planner-output.json` — planner(N1) 산출. record-result N1에 그대로 전달.
- **durable 맥락**: 메모리 `project_premortem_redesign.md` (2모드 oracle 전제 재정의·4 사용자결정·[DECIDED] 기본값·2 unknown). **읽어라.**
- **측정 근거(이번 세션)**: wi_26062227h 측정 = far-field 43% skip·비용 전제 약화. relevance provenance 영속(커밋 `ca796bc`, 미push).
- **대상 코드**: `coverage-taxonomy.ts`(FAR_FIELD floor 23 {id,lens}·routing 메타 無·resolveTaxonomy tier-② config·user_owned 상태), `coverage-loop.ts`(nextCoverageNode seed·완전성 술어 — **prism이 interview-driver.ts:17 통해 import → additive-only 강제**), `coverage-relevance.ts`, `schemas/coverage.ts`, `coverage-manager.ts`.

## 재개 절차 (autopilot 루프, 실행은 "진행해"로 이미 승인됨. plan-stage·n1-research는 DONE)
1. `ditto autopilot next-node --workItem wi_260706n4w` → **n2-schema-coverage(implement)** spawn. 이후 표준 loop: spawn owner → record-result(mutating은 changed_files 필수) → 반복. n2→n3→n4→n5→n6은 순차 의존, n7 review→n8 verify→n9 measure.
2. **각 implement 노드는 oracle-design-decisions.md + plan_brief 제약을 packet에 실어 위임.** 특히 n4(oracle): argv+`-F`+`--`+containment(cleanup-scan.ts:158·188-189 모방, :163 exit-coercion은 안티패턴), exit 3분기, AcOracle(coverage-manager.ts:616-671) 재사용, AST 금지. n5: enforceClose에 conditional·fail-open 신호(neutrality처럼 필수 아님).
3. n8 verify 후 n9(measure)는 log로 close 가능(ac-5 evidence=log, 실 dogfood before/after 수치는 실행 산물). complete 시 `ditto autopilot complete` → 7 AC evidence-gated.

## 설계 핵심 (구현 시 놓치지 말 것)
- **oracle = 2모드**: presence(인용 file:line 실재 grep/AST) + **absence('X 없음' 주장을 grep/AST로 반증)**. ⚠ **n1-research가 먼저 absence-mode 결정성 경계를 확정**해야 함 — 잘못하면 oracle 내부에 LLM 판단 재유입(신뢰성 문제가 oracle로 이동). 결정불가 claim은 advisory fallback.
- **strictness 위험-티어**: injection/secret만 hard-reject(fail-closed), 나머지 advisory. **tool 부재→advisory 강등**(ADR-0018 화해, ac-7).
- **라우팅 = 정적 disposition 필드**(동적 per-change 분류기 아님 — LLM 판단 재도입 배제). 이중성격 facet 분할(authz: 모델?→user-intent / 강제?→code-verify). tier-② config override.
- **완전성 silent narrowing 금지**(ac-3): 라우팅되어 sweep서 빠진 카테고리도 ledger에 disposition과 함께 잔류. 기존 no-silent-skip(ac-2) 정합.
- **minimal-increment 제거** → charter self-check/tidy 이관(먼 위험 아닌 설계-메타품질).
- **ac-5 측정(n9)**: dogfood 실제 wi의 before/after 날조율 + **oracle과 분리된 독립 라벨러**(n1이 정체 확정: 사람 or 다른 fresh-context). 순환 회피. in-code 완결 불가할 수 있음(실증분 vs 잔여 기록).
- **additive-only 강제(ac-6)**: FarFieldCategory·nextCoverageNode·완전성 술어 breaking 금지 → prism(parked, 구동 금지)·interview-driver 무파급. 지난 계측 슬라이스도 optional 인자만 추가해 무파급이었음.

## Gotcha
- coverage sweep·구현은 **fresh context**가 품질에 유리(이 handoff 이유). 서브에이전트 transcript 읽지 말고 structural 신호만.
- 빌드 `bun run build:bin`(CLI 변경 반영). 커밋 한국어 괄호 훅 오탐→`DITTO_SKIP_HOOKS=1 git commit -F file`. pre-commit biome lint 걸리면 `bun run lint:fix`.
- `evidence_required` enum = test|diff|browser|doc|log (**demo 없음**; 측정=log).
- 시스템 헤더 active pointer `wi_26062227h`(done)는 stale — 실작업은 wi_260706n4w.
- 전체 suite `bun test src tests`(~150s, 3982 pass 기준). tsc는 게이트 아님(453 기존 에러, test partial-payload 패턴).

## 금지 (scope creep)
- 7 AC·9노드 밖 기능 추가 금지. oracle 내부 LLM 판단 재유입 금지(absence-mode 결정성 필수). breaking change 금지(additive-only). push는 완결경계+사용자 명시 허가로만.
