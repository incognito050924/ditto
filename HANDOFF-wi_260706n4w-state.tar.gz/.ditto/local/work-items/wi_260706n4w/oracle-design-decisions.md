# oracle 설계 결정 (n1-research 산출 · n2/n4/n5/n9 구현 계약)

> wi_260706n4w. n1-research가 2개 intent unknown을 해소한 결과. 구현 노드는 이 결정을 재결정하지 말고 그대로 따른다.

## UNKNOWN 1 — absence-mode 결정성

**(A) 결정 가능한 absence-claim shape (prose 절대 금지):**
- `pattern: string` — 단일 non-whitespace 고정문자열 토큰. `ANCHOR_TOKEN = /^[^\s]+$/`(coverage-manager.ts:637) 재사용, 길이 상한.
- `scope_path: string` — repo-relative 경로. 사용 전 containment 통과 필수.
- `mode: 'absence'`. 기존 `AcOracle` triple에 매핑: `verification_method:'static_scan'`, `direction:'backward'`("현재 코드에 X 없음"=current-code finding), `maps_to: scope_path`. **필드 2개만 추가: `pattern` + `mode`.**
- 의미: "`scope_path` 안에 `pattern` 출현 없음". grep가 결정적으로 refute-or-confirm 가능한 유일한 shape.
- **presence-mode**: 기존 file:line regex `codePointerMapsTo = /^[^\s]+\.[A-Za-z0-9]+:[^\s]+$/`(work-item.ts:34) 재사용 — file 실재 + line 존재 확인. 새 citation 문법 안 만듦.

**(B) fallback 경계(정밀):** hard-verdict 가능 ⇔ token-shaped `pattern` AND containment-valid `scope_path` 둘 다. 하나라도 없거나 pattern이 whitespace/prose → decidable 아님 → `soft_judgment`/advisory(hard reject/pass 안 함). isReEvaluableAnchor(coverage-manager.ts:639-645)의 anchor-vs-label 분기와 동일. **tier 강도는 그 위에 얹힘**: injection/secret은 decidable-refuted면 hard-reject(fail-closed), 나머지 advisory. 단 decidable shape 미달 claim은 tier 무관 advisory.

**(C) exit-code 3분기 (MANDATORY):** `git grep` semantics — 0=match, 1=no-match, ≥2=error.
- exit **1** → CONFIRMED absent(claim 유지)
- exit **0** → REFUTED(없다던 토큰이 실재 → 날조 claim)
- exit **≥2** → advisory/unverified. **절대 "absent"로 coerce 금지.**
- ⚠ **안티패턴 확인됨**: `cleanup-scan.ts:163`이 `if (proc.exitCode !== 0) return false`로 exit 1과 ≥2를 합침 — **복사 금지**. exec 안전성(argv·-F·--)은 `cleanup-scan.ts:158`을 모방하되 exit 처리는 divergent하게 분기.

**(D) REUSE(재발명 금지):** 2-mode oracle은 `coverage-manager.ts:616-671` 어휘를 확장.
- `isReEvaluableAnchor`(:639) = "maps_to가 실제 path/file/rule 토큰, prose 아님" 검증 → `scope_path`·presence citation에 그대로 재사용(=cited-anchor-is-real presence 검사).
- `validateAcOracle`(:647): absence oracle은 static_scan+backward라 그대로 통과 + pattern-token 검사 추가.
- `oraclesEqual`(:665)/`assertOracleFrozen`(:681) 그대로. AcOracle triple(work-item.ts:36-67)이 citation 층. **net-new는 `runAbsenceCheck(pattern, scope_path, repoRoot)` executor 뿐.**

**(E) ADR-0006 — grep-only, AST 없음.** citation-existence(file:line 존재, 토큰 출현)는 textual presence이지 ACG 구조추출(call/import/dataflow, ADR-0006 D1 scope) 아님 → ADR-0006 거버넌스 밖. bespoke TS-compiler AST는 D2가 금지한 TS-only leak 재개통 → **거부.** 구조적 absence("X의 caller 없음")가 필요하면 그건 CodeQL 몫(ADR-0006 D1), 이 증분 out-of-scope. (ADR-0020 method 준수 disclosure.)

**(F) SECURITY(claim=신뢰불가 LLM output):** shape gate가 신뢰 경계.
- argv 배열만: `Bun.spawnSync(['git','grep','-F','-e',pattern,'--',scope_path],{cwd:repoRoot})`. `sh -c`/문자열보간 금지(cleanup-scan.ts:158). `-e`로 pattern 바인딩, `--`로 pathspec 앞 차단(leading `-` 플래그 파싱 방지).
- `-F` fixed-string(regex/injection meta 무력화).
- exec 전 `scope_path` containment: `isAbsolute(p)||p.startsWith('..')` 거부(cleanup-scan.ts:188-189), repoRoot 내 resolve.
- exec 전 shape gate: `pattern`은 ANCHOR_TOKEN + 길이상한. prose/whitespace는 shape gate서 reject→advisory. 검증된 단일 토큰은 multi-arg 확장 불가 → argv-injection 표면 제거.

## UNKNOWN 2 — 독립 라벨러(ac-5 순환)

- **정체**: oracle verdict를 재사용하지 않는 **별개 fresh-context host-delegated 에이전트(사람은 더 강한 옵션)**. ADR-0001: ditto는 provider 직접호출 안 함, 라벨러의 structured output만 consume(relevance refuter §5-3·session-blind reviewer 선례).
- **순환 차단 조건(셋 다 필요)**: (1) 라벨러 입력 = raw claim + 코드베이스, oracle verdict 절대 미포함; (2) fresh context(oracle 추론 없음); (3) 날조율은 **결정적 ditto 코드가 두 독립 집합**({oracle kept/rejected} vs {labeler real/fabricated})**을 상관**시켜 산출 — 어느 에이전트도 아님. **원칙: oracle=ENFORCE, labeler=JUDGE, 제3의 결정적 단계=CORRELATE.**
- **영속**: `relevanceProvenance`(coverage.ts:89-103) 미러 — raw `oracle_verdicts[]` + raw `labeler_labels[]` 별도 배열 + 결정적 tally.
- **n9 buildable**: 사이드카 스키마 + 결정적 날조율 계산 + 라벨러 계약(fresh 에이전트/SKILL, "코드베이스 대비 real vs fabricated, oracle output blind"). **residual**(log로 close, ac-5 evidence=log): 실제 before/after 수치는 진짜 dogfood wi를 재설계 전(옛 taxonomy) vs 후로 두 번 돌려야 나옴 — 코드는 하네스+스키마+계약 제공, 수치는 실행 산물(unit-test 불가).
- **uncertainty(residual)**: LLM 라벨러의 완전한 *판단* 독립성은 코드 강제 불가(모델패밀리 prior 공유 가능) → 절차적 독립(verdict-blind·fresh·별집합·결정적 상관)이 코드가 강제할 수 있는 최대. 완전 독립은 다른 모델/사람(옵션). intent의 "순환을 *완전히* 회피" = residual.

## 구현 순서 함의
- n2(schema): AcOracle triple에 `pattern`+`mode` 필드 additive(.optional, compat); oracle-verdict + labeler provenance 사이드카 스키마(relevanceProvenance 미러); disposition enum optional.
- n4(oracle-core): `runAbsenceCheck` + presence, exit 3분기, shape gate, argv 안전 exec. isReEvaluableAnchor/validateAcOracle 재사용. AST 안 함.
- n5(wiring): enforceClose에 **conditional·fail-open** 신호(neutrality처럼 필수 아님, balance/priority/temporal 패턴). advisory verdict는 사이드카로 영속.
- n9(measure): 라벨러 계약 + 결정적 상관 + before/after 로그.
